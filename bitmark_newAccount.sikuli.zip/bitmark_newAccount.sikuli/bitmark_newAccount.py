#creating new account

click("1488773496508.png")
click("1488713170933.png")
click("1488773575763.png")
paste("11521152")
click("1488713601744.png")
paste("11521152")
click("1488713302043.png")
wait("1488773611121.png", 20)
click("1488773620222.png")
