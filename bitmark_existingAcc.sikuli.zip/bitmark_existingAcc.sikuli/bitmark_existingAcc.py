#bitmark = App("Bitmark-devnet")
#if not bitmark.isRunning(): bitmark.open()
#wait(50)
#I want to automate opening the app, however the app always crashes


#accessing an existing account
click("1494829592699.png")
click("1488774599918.png")
access = input("Please enter your access key: ") #manually input an access key
click("1488774673151.png")
paste(access) #input the previously entered value
click("1488774684998.png")
passcode = input("Please enter a passcode: ")
click("1488774715623.png")
paste(passcode)
click("1488774734538.png")
paste(passcode)
click("1488774756132.png")