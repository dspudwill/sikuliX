#removing access from an existing account

click("1488773496508.png")
click("1494825465230.png")
click("1488774044810.png")
click("1494828185108.png")
paste("11521152")
click("1488774302757.png")